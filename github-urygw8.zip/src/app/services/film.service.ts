import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CreateFilmDto } from '../dtos/create-film-dto';
import { CreatedFilmDto } from '../dtos/created-film-dto';
import { DeleteFilmDto } from '../dtos/delete-film-dto';
import { FoundFilmsDto } from '../dtos/found-films-dto';
import { UpdateFilmDto } from '../dtos/update-film-dto';
import { UpdatedFilmDto } from '../dtos/updated-film-dto';

@Injectable({
  providedIn: 'root',
})
export class FilmService {
  constructor(private http: HttpClient) {}

  getAllFilms() {
    return this.http.get<FoundFilmsDto>('http://localhost:3000/Film/');
  }

  insertFilm(filmDto: UpdateFilmDto) {
    return this.http.put<UpdatedFilmDto>(
      `http://localhost:3000/Film/${filmDto.id}`,
      filmDto
    );
  }

  sendFilm(filmDto: CreateFilmDto) {
    return this.http.post<CreatedFilmDto>(
      'http://localhost:3000/Film/',
      filmDto
    );
  }

  removeFilm(filmDto: DeleteFilmDto) {
    return this.http.delete<DeletedFilmDto>(
      `http://localhost:3000/Film/${filmDto.id}`
    );
  }
}
