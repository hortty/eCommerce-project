export class GetCustomerDto {
  id: number;
}
