namespace eCommerce.Domain.DTOs 
{
    public class BaseDto
    {
        public long Id { get; set; }
        
    }

}