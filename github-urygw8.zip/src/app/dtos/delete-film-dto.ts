export class DeleteFilmDto {
  id: number;
}
