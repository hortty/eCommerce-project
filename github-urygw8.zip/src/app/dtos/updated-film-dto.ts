export class UpdatedFilmDto {
  id: number;
}
