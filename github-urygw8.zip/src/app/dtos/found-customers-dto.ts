import { FoundCustomerDto } from './found-customer-dto';

export class FoundCustomersDto {
  filmsListDto: FoundCustomerDto[];
}
