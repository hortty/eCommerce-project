using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerce.Application.Interfaces
{
    public class IGenericRepository
    {
        // TEntity List(TEntity entity);
    }
}