namespace eCommerce.Domain.DTOs 
{
    public class GetProductDto : BaseDto
    {

    }
}