export class FoundCustomerDto {
  id: number;

  name: string;

  phone: string;

  address: string;

  age: number;

  userId: number;
}
