export class UpdateFilmDto {
  id: number;

  name: string;

  description: string;

  price: number;
}
