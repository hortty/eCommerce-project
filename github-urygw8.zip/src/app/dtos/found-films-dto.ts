import { FoundFilmDto } from './found-film-dto';

export class FoundFilmsDto {
  filmsListDto: FoundFilmDto[];
}
