namespace eCommerce.Domain.DTOs 
{
    public class RemoveProductDto : BaseDto
    {

    }
}