import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CreateCustomerDto } from '../dtos/create-customer-dto';
import { CreatedCustomerDto } from '../dtos/created-customer-dto';
import { DeleteCustomerDto } from '../dtos/delete-customer-dto';
import { FoundCustomersDto } from '../dtos/found-customers-dto';
import { UpdateCustomerDto } from '../dtos/update-customer-dto';
import { UpdatedCustomerDto } from '../dtos/updated-customer-dto';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  constructor(private http: HttpClient) {}

  getAllCustomers() {
    return this.http.get<FoundCustomersDto>('http://localhost:3000/Customer/');
  }

  insertCustomer(customerDto: UpdateCustomerDto) {
    return this.http.put<UpdatedCustomerDto>(
      `http://localhost:3000/Customer/${customerDto.id}`,
      customerDto
    );
  }

  sendCustomer(customerDto: CreateCustomerDto) {
    return this.http.post<CreatedCustomerDto>(
      'http://localhost:3000/Customer/',
      customerDto
    );
  }

  removeCustomer(customerDto: DeleteCustomerDto) {
    return this.http.delete<DeletedCustomerDto>(
      `http://localhost:3000/Customer/${customerDto.id}`
    );
  }
}
