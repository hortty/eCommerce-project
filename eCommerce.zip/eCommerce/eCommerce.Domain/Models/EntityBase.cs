namespace eCommerce.Domain.Models 
{
    public abstract class EntityBase 
    {
        long Id { get; set; }
           
    }

}