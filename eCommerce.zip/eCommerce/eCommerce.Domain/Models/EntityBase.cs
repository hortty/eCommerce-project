namespace eCommerce.Domain.Models 
{
    public abstract class EntityBase 
    {
        public long Id { get; set; }
           
    }

}