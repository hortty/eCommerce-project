export class DeletedCustomerDto {
  id: string;
}
