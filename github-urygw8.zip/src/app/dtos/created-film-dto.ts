export class CreatedFilmDto {
  id: string;

  name: string;
}
