export class CreateFilmDto {
  name: string;

  description: string;

  price: number;

  amount: number;
}
