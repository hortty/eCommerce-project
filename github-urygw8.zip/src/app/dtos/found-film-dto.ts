export class FoundFilmDto {
  id: number;

  name: string;

  description: string;

  price: number;

  amount: number;
}
