using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GamesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        
        public ProductController()
        {
            
        }

        [HttpGet]
        public async Task<IActionResult> GetById([FromRoute] long id)
        {
            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> Post(Game game)
        {

        }

        [HttpPut]
        public async Task<IActionResult> Put(Game game)
        {

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Game game)
        {

        }

        [HttpGet("{id}")]
        public async Task<IActionResult> BuscarPorId(Guid id)
        {
        
        }
    }

}