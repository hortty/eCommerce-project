export class UpdatedCustomerDto {
  id: number;
}
