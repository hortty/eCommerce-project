export class DeletedFilmDto {
  id: string;
}
