import { Component } from '@angular/core';
import { FoundFilmsDto } from '../dtos/found-films-dto';
import { FilmService } from '../services/film.service';

@Component({
  selector: 'index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss'],
})
export class IndexComponent implements OnInit {
  filmList: FoundFilmsDto = new FoundFilmsDto();

  constructor(private filmService: FilmService) {}

  ngOnInit() {
    this.filmService.getAllFilms().subscribe((films) => {
      this.filmList = films;
    });
  }
}
