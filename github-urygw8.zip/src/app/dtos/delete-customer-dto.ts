export class DeleteCustomerDto {
  id: number;
}
