export class GetFilmDto {
  id: number;
}
