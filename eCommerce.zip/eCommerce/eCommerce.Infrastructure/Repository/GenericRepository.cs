using eCommerce.Domain.Models;
using eCommerce.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerce.Infrastructure.Repository
{
    public class GenericRepository
    {
        private readonly eCommerceContext _dbContext;
        public GenericRepository(eCommerceContext dbContext) 
        {
            _dbContext = dbContext;
        }

        public async Task<Product> GetById(long id)
        {
            var foundProduct = await _dbContext.Products.FindAsync(id);

            return foundProduct;
        }

        public async Task<Product> Update(Product product)
        {
            var foundProduct = await _dbContext.Products.FindAsync(product.Id);

            if(foundProduct == null)
            {
                return null;
            }

            var updatedProduct = _dbContext.Products.Update(product);
            await _dbContext.SaveChangesAsync();
            

            return updatedProduct.Entity;
        }

        public async Task<Product> Create(Product product)
        {
            var createdProduct = await _dbContext.Products.AddAsync(product);    
            await _dbContext.SaveChangesAsync();
            return createdProduct.Entity;
        }

        public async Task<Product> Delete(long id)
        {
            var foundProduct = await _dbContext.Products.FindAsync(id);

            if(foundProduct == null)
            {
                return null;
            }

            _dbContext.Products.Remove(foundProduct);
            await _dbContext.SaveChangesAsync();

            return foundProduct;
        }

        public async Task<IEnumerable<Product>> List(long id)
        {
            var products = await _dbContext.Products
                .AsNoTracking()
                .Where(x => x.Id == id)
                .ToListAsync();

            return products;
        }
    }
}