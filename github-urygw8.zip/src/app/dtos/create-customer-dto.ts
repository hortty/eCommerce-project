export class CreateCustomerDto {
  name: string;

  phone: string;

  address: string;

  age: number;

  userId: number;
}
