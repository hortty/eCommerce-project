export class CreatedCustomerDto {
  id: string;

  name: string;
}
